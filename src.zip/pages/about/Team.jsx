function Team() {
  return <div>/about/team 팀소개 페이지</div>;
}

export default Team;
