function Index() {
  return <div>about/소개의 첫페이지</div>;
}

export default Index;
