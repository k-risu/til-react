const Index = ({ title, year }) => {
  return (
    <div>
      {title} 첫 페이지 : 버전 {year}
    </div>
  );
};
export default Index;
