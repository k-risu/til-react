export const Footer = ({ children }) => {
  return <footer>{children}</footer>;
};
