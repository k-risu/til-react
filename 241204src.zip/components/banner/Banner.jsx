import { BannerStyleObj } from "../../styles/components/banner/banner-css";

const Banner = () => {
  return <div style={BannerStyleObj}>Banner</div>;
};

export default Banner;
