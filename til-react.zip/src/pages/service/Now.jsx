function Now() {
  return <div>/service/Now 지금 기술 페이지</div>;
}

export default Now;
