function Index() {
  return <div>/service 서비스 소개</div>;
}

export default Index;
