function List() {
  return <div>/blog/list?쿼리 블러그 목록 (queryString)</div>;
}

export default List;
