function Detail() {
  return <div>/blog/1 블로그 상세 페이지(RestAPI 방식)</div>;
}

export default Detail;
