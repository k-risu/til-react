function Index() {
  return <div>/blog 블로그 첫페이지</div>;
}

export default Index;
